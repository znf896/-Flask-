from distutils.core import setup
import glob

setup(name='ZNF-Webarc',
      version='1.0.0',
      description='Like Flask Frame',
      author='Znf',
      package=['webarc'],
      data_files=glob.glob('webarc/temps/*.html')
)